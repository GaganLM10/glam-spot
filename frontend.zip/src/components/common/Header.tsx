"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Menu, X, Scissors } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SITE_NAME } from "@/lib/constants";

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl text-zinc-900">
          <Scissors className="text-rose-500" size={22} />
          {SITE_NAME}
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm text-zinc-600">
          <Link href="/" className="hover:text-zinc-900 transition-colors">Home</Link>
          <Link href="/salons" className="hover:text-zinc-900 transition-colors">Salons</Link>
          <Link href="/services" className="hover:text-zinc-900 transition-colors">Services</Link>
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/auth/login">Login</Link>
          </Button>
          <Button size="sm" className="bg-rose-500 hover:bg-rose-600 text-white" asChild>
            <Link href="/auth/register">Sign Up</Link>
          </Button>
        </div>

        <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {menuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-white border-t border-zinc-100 px-4 py-4 flex flex-col gap-4 text-sm text-zinc-700"
        >
          <Link href="/" onClick={() => setMenuOpen(false)}>Home</Link>
          <Link href="/salons" onClick={() => setMenuOpen(false)}>Salons</Link>
          <Link href="/services" onClick={() => setMenuOpen(false)}>Services</Link>
          <Link href="/auth/login" onClick={() => setMenuOpen(false)}>Login</Link>
          <Link href="/auth/register" onClick={() => setMenuOpen(false)}>Sign Up</Link>
        </motion.div>
      )}
    </header>
  );
}