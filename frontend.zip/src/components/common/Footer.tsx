import Link from "next/link";
import { Scissors } from "lucide-react";
import { SITE_NAME } from "@/lib/constants";

export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-zinc-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 text-white font-bold text-lg mb-3">
            <Scissors className="text-rose-500" size={20} />
            {SITE_NAME}
          </div>
          <p className="text-zinc-500 text-xs leading-relaxed">
            Discover and book top salons & spas near you. Beauty at your fingertips.
          </p>
        </div>

        <div>
          <h4 className="text-white font-medium mb-3">Explore</h4>
          <ul className="space-y-2">
            <li><Link href="/salons" className="hover:text-white transition-colors">Salons</Link></li>
            <li><Link href="/services" className="hover:text-white transition-colors">Services</Link></li>
            <li><Link href="/cities" className="hover:text-white transition-colors">Cities</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-medium mb-3">Company</h4>
          <ul className="space-y-2">
            <li><Link href="/about" className="hover:text-white transition-colors">About</Link></li>
            <li><Link href="/careers" className="hover:text-white transition-colors">Careers</Link></li>
            <li><Link href="/contact" className="hover:text-white transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-medium mb-3">Legal</h4>
          <ul className="space-y-2">
            <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            <li><Link href="/terms" className="hover:text-white transition-colors">Terms of Use</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-zinc-800 text-center py-4 text-xs text-zinc-600">
        © {new Date().getFullYear()} {SITE_NAME}. All rights reserved.
      </div>
    </footer>
  );
}